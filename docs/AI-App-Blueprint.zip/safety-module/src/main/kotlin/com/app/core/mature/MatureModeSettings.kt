package com.app.core.mature

import com.app.core.safety.IntegrityCheck

enum class Explicitness { MILD, STRONG, EXPLICIT }
enum class Tone { NEUTRAL, PLAYFUL, BLUNT }

/**
 * Everything a user can change about Mature Mode. Note what is NOT here: there is no field
 * for the fixed limits, so no setting can reach them.
 */
data class MatureModeSettings(
    val enabled: Boolean = false,
    val explicitness: Explicitness = Explicitness.STRONG,
    val tone: Tone = Tone.NEUTRAL,
    val customInstructions: String = "",
)

sealed interface EnableResult {
    data object Enabled : EnableResult
    data object NeedsAgeVerification : EnableResult
    data object SafetyFilesInvalid : EnableResult
}

class MatureModeController(
    private val ageGate: AgeGate,
    private val integrity: IntegrityCheck,
) {
    var settings: MatureModeSettings = MatureModeSettings()
        private set

    fun enable(): EnableResult {
        if (!ageGate.isVerifiedAdult) return EnableResult.NeedsAgeVerification
        if (!integrity.verified) return EnableResult.SafetyFilesInvalid
        settings = settings.copy(enabled = true)
        return EnableResult.Enabled
    }

    fun disable() {
        settings = settings.copy(enabled = false)
    }

    fun update(change: (MatureModeSettings) -> MatureModeSettings) {
        val next = change(settings)
        // Turning it on still has to go through enable().
        settings = if (next.enabled && !settings.enabled) next.copy(enabled = false) else next
    }

    /** Locks Mature Mode if the safety files stop verifying (checked at app start and on model load). */
    fun revalidate() {
        if (settings.enabled && (!integrity.verified || !ageGate.isVerifiedAdult)) disable()
    }
}
