package com.app.core.mature

/** Result from an age-verification provider (ID check, payment-card check, or similar). */
sealed interface AgeResult {
    data object VerifiedAdult : AgeResult
    data object Underage : AgeResult
    data class Failed(val reason: String) : AgeResult
}

interface AgeVerifier {
    suspend fun verify(): AgeResult
}

/** Encrypted key-value storage (Android Keystore-backed on device). */
interface SecureStore {
    fun getBoolean(key: String): Boolean
    fun putBoolean(key: String, value: Boolean)
}

class AgeGate(private val verifier: AgeVerifier, private val store: SecureStore) {

    val isVerifiedAdult: Boolean get() = store.getBoolean(KEY)

    suspend fun verify(): AgeResult {
        val result = verifier.verify()
        store.putBoolean(KEY, result == AgeResult.VerifiedAdult)
        return result
    }

    private companion object {
        const val KEY = "age_verified_adult"
    }
}
