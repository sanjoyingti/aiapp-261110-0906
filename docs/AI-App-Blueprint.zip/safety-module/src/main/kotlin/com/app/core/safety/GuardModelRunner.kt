package com.app.core.safety

enum class GuardRole { USER, ASSISTANT }

data class GuardVerdict(val scores: Map<HardLimit, Float>) {
    fun violated(threshold: Float = SafetyPolicy.BLOCK_THRESHOLD): HardLimit? =
        scores.filterValues { it >= threshold }.maxByOrNull { it.value }?.key

    companion object {
        val CLEAN = GuardVerdict(emptyMap())
    }
}

/** A small classifier model that labels text against the fixed limits. */
interface GuardModelRunner {
    val isReady: Boolean
    suspend fun classify(text: String, role: GuardRole, context: List<String> = emptyList()): GuardVerdict
}

/** Minimal surface of the on-device llama.cpp engine (JNI bridge lives in the android module). */
interface LocalLlmEngine {
    val isLoaded: Boolean
    suspend fun complete(prompt: String, maxTokens: Int, temperature: Float = 0f): String
}

/**
 * Runs a Llama Guard / ShieldGemma-class GGUF through llama.cpp with a custom taxonomy
 * containing only the three fixed limits. The guard answers "safe" or "unsafe" plus codes.
 */
class LlamaCppGuardRunner(private val engine: LocalLlmEngine) : GuardModelRunner {

    override val isReady: Boolean get() = engine.isLoaded

    override suspend fun classify(text: String, role: GuardRole, context: List<String>): GuardVerdict {
        val raw = engine.complete(buildPrompt(text, role, context), maxTokens = 12)
        return parse(raw)
    }

    internal fun buildPrompt(text: String, role: GuardRole, context: List<String>): String = buildString {
        append("Task: Check if there is unsafe content in the '")
        append(if (role == GuardRole.USER) "User" else "Agent")
        append("' message below according to these categories. ")
        append("Adult sexual content between consenting adults, fiction, and educational or defensive ")
        append("discussion are SAFE unless they fall in a category.\n\n")
        append("<BEGIN UNSAFE CONTENT CATEGORIES>\n")
        append("C1: Sexual content involving or sexualizing anyone under 18.\n")
        append("C2: Sexual or nude content depicting a real, identifiable person.\n")
        append("C3: Actionable help building weapons capable of mass harm, or creating malware.\n")
        append("<END UNSAFE CONTENT CATEGORIES>\n\n")
        append("<BEGIN CONVERSATION>\n")
        context.forEach { append(it).append("\n\n") }
        append(if (role == GuardRole.USER) "User: " else "Agent: ").append(text)
        append("\n<END CONVERSATION>\n\n")
        append("Answer 'safe' or 'unsafe'. If unsafe, put the violated category codes on the second line, comma-separated.")
    }

    internal fun parse(raw: String): GuardVerdict {
        val lines = raw.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty() || lines.first().equals("safe", ignoreCase = true)) return GuardVerdict.CLEAN
        val codes = lines.getOrNull(1)?.split(',').orEmpty().mapNotNull { HardLimit.fromCode(it) }
        // "unsafe" with no recognisable code still blocks, attributed to the most severe limit.
        val hits = codes.ifEmpty { listOf(HardLimit.MINOR_SEXUAL) }
        return GuardVerdict(hits.associateWith { 1f })
    }
}
