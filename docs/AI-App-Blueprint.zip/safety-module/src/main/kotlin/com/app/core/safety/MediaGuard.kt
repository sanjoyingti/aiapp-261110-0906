package com.app.core.safety

/** Signals from an on-device image classifier (e.g. a small NSFW + age-estimation model). */
data class ImageSignals(
    val explicit: Float,
    val apparentMinor: Float,
    val identifiableFaces: Int,
)

interface ImageSafetyClassifier {
    val isReady: Boolean
    suspend fun analyze(image: ImageData): ImageSignals
}

/** Checks image/video prompts, uploaded images, and generated frames. */
class MediaGuard(
    private val guard: GuardModelRunner,
    private val images: ImageSafetyClassifier,
    private val realPerson: RealPersonGuard,
) {
    val isReady: Boolean get() = guard.isReady && images.isReady

    /** Text prompt for image or video generation. */
    suspend fun checkMediaPrompt(prompt: String): HardLimit? =
        guard.classify(prompt, GuardRole.USER).violated()

    /** An image the user attached, together with what they asked for. */
    suspend fun checkImageInput(image: ImageData, instruction: String): HardLimit? {
        val s = images.analyze(image)
        if (s.apparentMinor >= SafetyPolicy.BLOCK_THRESHOLD && s.explicit >= SafetyPolicy.BLOCK_THRESHOLD) {
            return HardLimit.MINOR_SEXUAL
        }
        if (s.apparentMinor >= SafetyPolicy.BLOCK_THRESHOLD) {
            val v = guard.classify("[Attached: photo of a child] $instruction", GuardRole.USER).violated()
            if (v == HardLimit.MINOR_SEXUAL) return v
        }
        return realPerson.check(s, instruction)
    }

    /** Every generated image, and sampled frames of every generated video, before display. */
    suspend fun checkGeneratedFrame(frame: ImageData): HardLimit? {
        val s = images.analyze(frame)
        return if (s.apparentMinor >= SafetyPolicy.BLOCK_THRESHOLD && s.explicit >= SafetyPolicy.BLOCK_THRESHOLD) {
            HardLimit.MINOR_SEXUAL
        } else null
    }
}
