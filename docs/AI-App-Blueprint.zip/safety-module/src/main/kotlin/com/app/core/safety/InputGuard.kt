package com.app.core.safety

/** Checks the user's message and every attachment before any model sees them. */
class InputGuard(
    private val guard: GuardModelRunner,
    private val media: MediaGuard,
) {
    suspend fun check(req: ChatRequest): HardLimit? {
        val text = buildString {
            append(req.userText)
            req.attachments.forEach { a ->
                a.extractedText?.let { append("\n\n[Attachment ${a.name}]\n").append(it.take(SafetyPolicy.ATTACHMENT_CHECK_CHARS)) }
            }
        }
        guard.classify(text, GuardRole.USER, req.recentTurns()).violated()?.let { return it }

        for (a in req.attachments) {
            val img = a.image ?: continue
            media.checkImageInput(img, req.userText)?.let { return it }
        }
        return null
    }
}
