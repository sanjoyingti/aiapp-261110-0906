package com.app.core.safety

/**
 * The fixed limits. These are compiled constants: no settings screen, config file,
 * system prompt or loaded model can add to, remove from, or relax this set.
 */
enum class HardLimit(val code: String, val userMessage: String) {
    MINOR_SEXUAL(
        code = "C1",
        userMessage = "I can't help with sexual content involving minors.",
    ),
    REAL_PERSON_SEXUAL(
        code = "C2",
        userMessage = "I can't create sexual content of a real, identifiable person.",
    ),
    WEAPONS_MALWARE(
        code = "C3",
        userMessage = "I can't help build weapons or malware.",
    );

    companion object {
        fun fromCode(code: String): HardLimit? = entries.firstOrNull { it.code == code.trim() }
    }
}

object SafetyPolicy {
    /** Every limit is always on. There is intentionally no way to construct a smaller set. */
    val limits: Set<HardLimit> = HardLimit.entries.toSet()

    /** Score at or above which a guard verdict blocks. */
    const val BLOCK_THRESHOLD: Float = 0.5f

    /** Output is released to the UI / TTS in checked windows of this many characters. */
    const val STREAM_CHECK_CHARS: Int = 400

    /** Each check also re-reads this much already-released text, so a violation split across windows is caught. */
    const val STREAM_OVERLAP_CHARS: Int = 200

    /** Max characters of an attachment's extracted text sent to the input check. */
    const val ATTACHMENT_CHECK_CHARS: Int = 8_000
}
