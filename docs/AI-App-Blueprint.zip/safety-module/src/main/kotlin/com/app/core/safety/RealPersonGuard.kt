package com.app.core.safety

/**
 * Blocks sexual or nude edits of photos showing real, identifiable people.
 * Ordinary edits of real photos (background, lighting, style, clothing that isn't sexualised) pass.
 */
class RealPersonGuard(private val guard: GuardModelRunner) {

    suspend fun check(signals: ImageSignals, instruction: String): HardLimit? {
        if (signals.identifiableFaces == 0) return null
        val framed = "[Attached: photo of a real, identifiable person] $instruction"
        return when (guard.classify(framed, GuardRole.USER).violated()) {
            HardLimit.REAL_PERSON_SEXUAL -> HardLimit.REAL_PERSON_SEXUAL
            HardLimit.MINOR_SEXUAL -> HardLimit.MINOR_SEXUAL
            else -> null
        }
    }
}
