package com.app.core.safety

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Persists counters only (e.g. DataStore on Android). */
interface CounterStore {
    fun load(): Map<String, Int>
    fun save(counts: Map<String, Int>)
}

/** Local-only block counters per limit. Never stores message content and never leaves the device. */
class SafetyEvents(private val store: CounterStore? = null) {
    private val counts = ConcurrentHashMap<HardLimit, AtomicInteger>().apply {
        store?.load()?.forEach { (code, n) -> HardLimit.fromCode(code)?.let { put(it, AtomicInteger(n)) } }
    }

    fun record(limit: HardLimit) {
        counts.getOrPut(limit) { AtomicInteger(0) }.incrementAndGet()
        store?.save(snapshot().mapKeys { it.key.code })
    }

    fun snapshot(): Map<HardLimit, Int> = counts.mapValues { it.value.get() }
}
