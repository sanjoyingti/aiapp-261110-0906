package com.app.core.safety

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach

/**
 * The only path from the chat, voice and agent layers to any model. The router holds a
 * [SafetyInterceptor], never a bare [ModelClient], so no route can skip the checks.
 *
 * Fails closed: if the guard model isn't loaded or failed its integrity check, nothing is generated.
 */
class SafetyInterceptor(
    private val guard: GuardModelRunner,
    private val inputGuard: InputGuard,
    private val outputGuard: OutputGuard,
    private val integrity: IntegrityCheck,
    private val events: SafetyEvents,
) {
    val isOperational: Boolean get() = guard.isReady && integrity.verified

    fun stream(client: ModelClient, chat: ChatRequest): Flow<GuardedChunk> = flow {
        if (!isOperational) {
            emit(GuardedChunk.SafetyUnavailable)
            return@flow
        }

        inputGuard.check(chat)?.let { limit ->
            events.record(limit)
            emit(GuardedChunk.Blocked(limit))
            return@flow
        }

        val request = ModelRequest(
            systemPrompt = PolicyPrompt.compose(chat.userInstructions, chat.matureMode),
            messages = chat.history + Message(Role.USER, chat.userText),
        )

        outputGuard.guard(client.stream(request), chat.recentTurns())
            .onEach { if (it is GuardedChunk.Blocked) events.record(it.limit) }
            .collect { emit(it) }
    }
}
