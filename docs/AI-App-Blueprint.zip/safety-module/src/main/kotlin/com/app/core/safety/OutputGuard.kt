package com.app.core.safety

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Checks a model's streamed output in windows before releasing it.
 * Text reaches the UI or the TTS only after its window passes, so blocked text is never shown or spoken.
 * Each check also re-reads the tail of already-released text, so a violation split across two
 * windows is still caught. On a violation the upstream model stream is cancelled.
 */
class OutputGuard(
    private val guard: GuardModelRunner,
    private val windowChars: Int = SafetyPolicy.STREAM_CHECK_CHARS,
    private val overlapChars: Int = SafetyPolicy.STREAM_OVERLAP_CHARS,
) {
    private class StopStream : CancellationException("output blocked")

    fun guard(upstream: Flow<String>, context: List<String> = emptyList()): Flow<GuardedChunk> = flow {
        var released = ""
        val pending = StringBuilder()

        suspend fun releasePending(): HardLimit? {
            if (pending.isEmpty()) return null
            val candidate = pending.toString()
            val verdict = guard.classify(released.takeLast(overlapChars) + candidate, GuardRole.ASSISTANT, context)
            verdict.violated()?.let { return it }
            emit(GuardedChunk.Text(candidate))
            released = (released + candidate).takeLast(overlapChars)
            pending.clear()
            return null
        }

        try {
            upstream.collect { piece ->
                pending.append(piece)
                if (pending.length >= windowChars) {
                    releasePending()?.let { limit ->
                        emit(GuardedChunk.Blocked(limit))
                        throw StopStream()
                    }
                }
            }
            releasePending()?.let { emit(GuardedChunk.Blocked(it)) }
        } catch (e: StopStream) {
            // Upstream was cancelled by the throw; the Blocked chunk is already emitted.
        }
    }
}
