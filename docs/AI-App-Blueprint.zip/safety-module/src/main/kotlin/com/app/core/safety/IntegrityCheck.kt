package com.app.core.safety

import java.io.File
import java.security.MessageDigest

/**
 * Verifies the safety model files against SHA-256 hashes compiled into the app (BuildConfig),
 * not against a hash file sitting next to the model, which could be edited along with it.
 */
class IntegrityCheck(private val expected: Map<File, String>) {

    @Volatile
    var verified: Boolean = false
        private set

    fun run(): Boolean {
        verified = expected.isNotEmpty() && expected.all { (file, hash) ->
            file.isFile && sha256(file).equals(hash, ignoreCase = true)
        }
        return verified
    }

    companion object {
        fun sha256(file: File): String {
            val md = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
