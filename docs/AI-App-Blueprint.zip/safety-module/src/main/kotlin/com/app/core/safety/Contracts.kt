package com.app.core.safety

import kotlinx.coroutines.flow.Flow

/** Where a model call is going. Every route passes through [SafetyInterceptor]. */
enum class Route { LOCAL, HOME_BRAIN, CLOUD }

enum class Role { SYSTEM, USER, ASSISTANT }

data class Message(val role: Role, val text: String)

/** Raw image bytes plus format, e.g. "image/jpeg". */
class ImageData(val bytes: ByteArray, val mimeType: String)

data class Attachment(
    val name: String,
    val extractedText: String? = null,
    val image: ImageData? = null,
)

/** What the chat layer hands to the safety layer. */
data class ChatRequest(
    val userText: String,
    val history: List<Message> = emptyList(),
    val attachments: List<Attachment> = emptyList(),
    val userInstructions: String = "",
    val matureMode: Boolean = false,
) {
    fun recentTurns(n: Int = 6): List<String> = history.takeLast(n).map { "${it.role}: ${it.text}" }
}

/** What actually goes to a model. */
data class ModelRequest(val systemPrompt: String, val messages: List<Message>)

/** Any model backend: llama.cpp on the phone, the home brain, or the cloud gateway. */
interface ModelClient {
    val route: Route
    fun stream(request: ModelRequest): Flow<String>
}

/** What the UI and the voice engine receive. Only [Text] is ever shown or spoken. */
sealed interface GuardedChunk {
    data class Text(val text: String) : GuardedChunk
    data class Blocked(val limit: HardLimit) : GuardedChunk {
        val message: String get() = limit.userMessage
    }
    /** The safety model is missing or failed its integrity check, so nothing is generated. */
    data object SafetyUnavailable : GuardedChunk
}
