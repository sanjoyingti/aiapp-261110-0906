// Spec 1 reference: Real-Time Interruption Voice Engine core state machine.
package com.aiapp.voice

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger

enum class VState { IDLE, LISTENING, THINKING, SPEAKING, INTERRUPTED }

interface Player { fun enqueue(pcm: ByteArray); fun pauseAndFlush(); fun spokenText(): String }
interface LlmStream { suspend fun cancel(turn: Int) }
interface TtsStream { suspend fun cancel(turn: Int) }
interface SttStream { fun send(frame: ShortArray) }
interface History { fun truncateTo(heardText: String) }
interface BargeInDetector { fun update(speechProb: Float, frame: ShortArray): Boolean }

class RingBuffer(ms: Int, sampleRate: Int = 16_000) {
    private val buf = ShortArray(ms * sampleRate / 1000)
    private var pos = 0
    private var filled = 0
    fun write(frame: ShortArray) { for (s in frame) { buf[pos] = s; pos = (pos + 1) % buf.size; if (filled < buf.size) filled++ } }
    fun drain(): ShortArray {
        val out = ShortArray(filled) { i -> buf[(pos - filled + i + buf.size) % buf.size] }
        filled = 0
        return out
    }
}

class VoiceSession(
    private val player: Player,
    private val llm: LlmStream,
    private val tts: TtsStream,
    private val stt: SttStream,
    private val history: History,
    private val bargeIn: BargeInDetector,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow(VState.IDLE)
    val state = _state.asStateFlow()
    private val epoch = AtomicInteger(0)
    private val preRoll = RingBuffer(ms = 300)

    fun onMicFrame(frame: ShortArray, speechProb: Float) {
        preRoll.write(frame)
        when (_state.value) {
            VState.SPEAKING, VState.THINKING -> if (bargeIn.update(speechProb, frame)) interrupt()
            VState.LISTENING -> stt.send(frame)
            else -> Unit
        }
    }

    private fun interrupt() {
        _state.value = VState.INTERRUPTED
        player.pauseAndFlush()                              // 1. silence now
        val old = epoch.getAndIncrement()                   // 2. drop stale packets
        scope.launch { llm.cancel(old); tts.cancel(old) }   // 3. cancel generation
        history.truncateTo(player.spokenText())             // 4. keep only what was heard
        stt.send(preRoll.drain())                           // 5. don't lose first words
        _state.value = VState.LISTENING                     // 6. listen
    }

    fun onTtsChunk(turn: Int, pcm: ByteArray) {
        if (turn != epoch.get()) return
        if (_state.value == VState.THINKING) _state.value = VState.SPEAKING
        player.enqueue(pcm)
    }
}
